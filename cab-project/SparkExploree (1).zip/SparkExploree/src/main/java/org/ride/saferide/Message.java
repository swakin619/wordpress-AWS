package org.ride.saferide;

import java.util.ArrayList;
import java.util.List;

/**
 * Author Swetha Gajam
 * Created on 4/16/2016.
 */
public class Message {

    public Message(String value, String type) {
        List<String> messages = new ArrayList<>();
        messages.add(value);
        this.values = messages;
        this.type = type;
    }

    public Message(List<String> values) {
        this(values, "info");
    }

    public Message(List<String> values, String type) {
        this.type = type;
        this.values = values;
    }

    public Message(String value) {
        this(value, "info");
    }

    private String type;

    private List<String> values;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getValues() {
        return values;
    }

    public void setValues(List<String> values) {
        this.values = values;
    }
}
