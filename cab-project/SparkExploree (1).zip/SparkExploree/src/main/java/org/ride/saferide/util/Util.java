package org.ride.saferide.util;

/**
 * Created on 4/16/2016.
 */
public class Util {
    private Util () {}

    /**
     * Parse int
     * @param str String to be parsed
     * @return int
     */
    public static int parseInt(String str) {
        try { return Integer.parseInt(str); } catch (Exception e) {}
        return 0;
    }

    /**
     * Check if str is empty
     * @param str String
     * @return boolean
     */
    public static boolean isEmpty(String str) {
        return (str == null || str.trim().isEmpty());
    }
}
