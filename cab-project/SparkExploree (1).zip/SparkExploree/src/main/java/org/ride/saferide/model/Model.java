package org.ride.saferide.model;

import java.sql.Timestamp;
import java.util.List;

/**
 * Created on 4/16/2016.
 */
public interface Model {
    /**
     * Get all students
     * @return students
     */
    List<Student> getStudents();

    /**
     * Get student by id
     * @param id Student id
     * @return student
     */
    Student getStudentById(String id);

    /**
     * Get all drivers
     * @return driver
     */
    List<Driver> getDrivers();

    /**
     * Get driver by id
     * @param id Driver id
     * @return driver
     */
    Driver getDriver(int id);

    /**
     * Get all places which the app supports
     * @return places
     */
    List<Place> getPlaces();

    /**
     * Get schedule by id
     * @param id Id
     * @return schedule
     */
    Schedule getSchedule(int id);

    /**
     * Get schedules of drivers
     * @param driverId Driver id
     * @return schedule
     */
    List<Schedule> getSchedulesOfDriver(int driverId);

    /**
     * Get schedules of student
     * @param studentId Student id
     * @return schedule
     */
    List<Schedule> getSchedulesOfStudent(String studentId);

    /**
     * Get all schedules of a driver whose schedule
     * pickup time or drop time
     * is in between start time and end time
     * @param driverId Driver id
     * @param startTime Start time
     * @param endTime End time
     * @return schedules
     */
    List<Schedule> getSchedulesOfDriverInTimes(int driverId,
                                               Timestamp startTime,
                                               Timestamp endTime);

    /**
     * Add schedule
     * @param schedule schedule
     * @return id
     */
    long addSchedule(Schedule schedule);

    /**
     * Cancel this schedule
     * @param schedule schedule
     */
    void cancelSchedule(Schedule schedule);
}
