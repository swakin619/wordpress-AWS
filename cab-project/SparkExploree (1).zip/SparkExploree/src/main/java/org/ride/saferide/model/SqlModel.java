package org.ride.saferide.model;

import org.sql2o.Connection;
import org.sql2o.Query;
import org.sql2o.Sql2o;

import java.sql.Timestamp;
import java.util.List;

/**
 * Created on 4/16/2016.
 */
public class SqlModel implements Model {
    private Sql2o sql2o;

    public SqlModel(Sql2o sql2o) {
        this.sql2o = sql2o;
    }

    @Override
    public List<Student> getStudents() {
        try (Connection connection = sql2o.open()) {
            return connection
                    .createQuery(String.format("select * from %s", Student.TABLE))
                    .executeAndFetch(Student.class);
        }
    }

    @Override
    public Student getStudentById(String id) {
        try (Connection connection = sql2o.open()) {
            return connection
                    .createQuery(String.format("select * from %s where id = :id", Student.TABLE))
                    .addParameter("id", id)
                    .executeAndFetchFirst(Student.class);
        }
    }

    @Override
    public List<Driver> getDrivers() {
        try (Connection connection = sql2o.open()) {
            return connection
                    .createQuery(String.format("select * from %s", Driver.TABLE))
                    .executeAndFetch(Driver.class);
        }
    }

    @Override
    public Driver getDriver(int id) {
        try (Connection connection = sql2o.open()) {
            return connection
                    .createQuery(String.format("select * from %s where id = :id", Driver.TABLE))
                    .addParameter("id", id)
                    .executeAndFetchFirst(Driver.class);
        }
    }

    @Override
    public List<Place> getPlaces() {
        try (Connection connection = sql2o.open()) {
            return connection
                    .createQuery(String.format("select * from %s", Place.TABLE))
                    .executeAndFetch(Place.class);
        }
    }

    @Override
    public Schedule getSchedule(int id) {
        String placeSql = String.format("select * from %s where id = :id", Place.TABLE);
        String driverSql = String.format("select * from %s where id = :id", Driver.TABLE);
        try (Connection connection = sql2o.open()) {
            Schedule schedule = connection
                    .createQuery(String.format("select * from %s where id = :id",
                            Schedule.TABLE))
                    .addParameter("id", id)
                    .executeAndFetchFirst(Schedule.class);
            if (schedule != null) {
                Place source = connection.createQuery(placeSql).addParameter("id", schedule.getSourceId())
                        .executeAndFetchFirst(Place.class);
                Place destination = connection.createQuery(placeSql).addParameter("id", schedule.getDestinationId())
                        .executeAndFetchFirst(Place.class);
                Driver driver = connection.createQuery(driverSql).addParameter("id", schedule.getDriverId())
                        .executeAndFetchFirst(Driver.class);
                schedule.setDriver(driver);
                schedule.setSource(source);
                schedule.setDestination(destination);
            }
            return schedule;
        }
    }

    @Override
    public List<Schedule> getSchedulesOfDriver(int driverId) {
        try (Connection connection = sql2o.open()) {
            return connection
                    .createQuery(String.format("select * from %s where driverId = :driverId" +
                            " order by pickUpTime", Schedule.TABLE))
                    .addParameter("driverId", driverId)
                    .executeAndFetch(Schedule.class);
        }
    }

    @Override
    public List<Schedule> getSchedulesOfStudent(String studentId) {
        String placeSql = String.format("select * from %s where id = :id", Place.TABLE);
        String driverSql = String.format("select * from %s where id = :id", Driver.TABLE);
        try (Connection connection = sql2o.open()) {
            List<Schedule> schedules = connection
                    .createQuery(String.format("select * from %s where studentId = :studentId" +
                            " order by pickUpTime desc", Schedule.TABLE))
                    .addParameter("studentId", studentId)
                    .executeAndFetch(Schedule.class);
            // Not the best way. But does the job
            schedules.forEach((schedule -> {
                Place source = connection.createQuery(placeSql).addParameter("id", schedule.getSourceId())
                        .executeAndFetchFirst(Place.class);
                Place destination = connection.createQuery(placeSql).addParameter("id", schedule.getDestinationId())
                        .executeAndFetchFirst(Place.class);
                Driver driver = connection.createQuery(driverSql).addParameter("id", schedule.getDriverId())
                        .executeAndFetchFirst(Driver.class);
                schedule.setSource(source);
                schedule.setDestination(destination);
                schedule.setDriver(driver);
            }));
            return schedules;
        }
    }

    @Override
    public List<Schedule> getSchedulesOfDriverInTimes(int driverId,
                                                      Timestamp startTime,
                                                      Timestamp endTime) {
        try (Connection connection = sql2o.open()) {

            return connection
                    .createQuery(String.format("select * from %s where " +
                            " driverId = :driverId " +
                            " and " +
                            " (pickUpTime <= :startTime and dropTime >= :startTime)" +
                            " and " +
                            " (pickUpTime <= :endTime and dropTime >= :endTime)" +
                            " and status != 'cancelled'",
                        Schedule.TABLE))
                    .addParameter("driverId", driverId)
                    .addParameter("startTime", startTime)
                    .addParameter("endTime", endTime)
                    .executeAndFetch(Schedule.class);
        }
    }

    @Override
    public long addSchedule(Schedule schedule) {
        String sql = String.format("insert into %s (studentId, sourceId, destinationId," +
                "driverId, pickUpTime, dropTime, distance, type, passengers, status) values(" +
                ":studentId, :sourceId, :destinationId, :driverId, :pickUpTime, :dropTime, " +
                ":distance, :type, :passengers, :status)", Schedule.TABLE);
        long id = 0;
        try (Connection connection = sql2o.open()) {
            id = (long) connection
                    .createQuery(sql)
                    .bind(schedule)
                    .executeUpdate()
                    .getKey();
        }
        return id;
    }

    @Override
    public void cancelSchedule(Schedule schedule) {
        String sql = String.format("update %s set status = :status where id = :id", Schedule.TABLE);
        try (Connection connection = sql2o.open()) {
            connection
                    .createQuery(sql)
                    .addParameter("status", "cancelled")
                    .addParameter("id", schedule.getId())
                    .executeUpdate();
        }
    }
}