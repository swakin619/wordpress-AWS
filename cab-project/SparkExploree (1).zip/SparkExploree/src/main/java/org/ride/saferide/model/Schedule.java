package org.ride.saferide.model;

import java.sql.Timestamp;

/**
 * Created on 4/16/2016.
 */
public class Schedule {

    public static String TABLE = "schedules";

    private int id;
    private String studentId;
    private int sourceId;
    private int destinationId;
    private int driverId;
    private Timestamp pickUpTime;
    private Timestamp dropTime;
    private int distance;
    private String type;
    private int passengers;

    /**
     * Status (cancelled is the schedule is cancelled)
     */
    private String status;

    private String pickUpTimeString;

    private Student student;
    private Place destination;
    private Driver driver;
    private Place source;

    private String className;
    private String statusDesc;

    private boolean canBeCancelled;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSourceId() {
        return sourceId;
    }

    public void setSourceId(int sourceId) {
        this.sourceId = sourceId;
    }

    public int getDestinationId() {
        return destinationId;
    }

    public void setDestinationId(int destinationId) {
        this.destinationId = destinationId;
    }

    public int getDriverId() {
        return driverId;
    }

    public void setDriverId(int driverId) {
        this.driverId = driverId;
    }

    public Timestamp getPickUpTime() {
        return pickUpTime;
    }

    public void setPickUpTime(Timestamp pickUpTime) {
        this.pickUpTime = pickUpTime;
    }

    public Timestamp getDropTime() {
        return dropTime;
    }

    public void setDropTime(Timestamp dropTime) {
        this.dropTime = dropTime;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public Place getDestination() {
        return destination;
    }

    public void setDestination(Place destination) {
        this.destination = destination;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public Place getSource() {
        return source;
    }

    public void setSource(Place source) {
        this.source = source;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getPassengers() {
        return passengers;
    }

    public void setPassengers(int passengers) {
        this.passengers = passengers;
    }

    public String getPickUpTimeString() {
        return pickUpTimeString;
    }

    public void setPickUpTimeString(String pickUpTimeString) {
        this.pickUpTimeString = pickUpTimeString;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Schedule{" +
                "id=" + id +
                ", studentId='" + studentId + '\'' +
                ", sourceId=" + sourceId +
                ", destinationId=" + destinationId +
                ", driverId=" + driverId +
                ", pickUpTime=" + pickUpTime +
                ", dropTime=" + dropTime +
                ", distance=" + distance +
                ", type='" + type + '\'' +
                ", passengers=" + passengers +
                ", status='" + status + '\'' +
                ", pickUpTimeString='" + pickUpTimeString + '\'' +
                ", student=" + student +
                ", destination=" + destination +
                ", driver=" + driver +
                ", source=" + source +
                '}';
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getStatusDesc() {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    public boolean isCanBeCancelled() {
        return canBeCancelled;
    }

    public void setCanBeCancelled(boolean canBeCancelled) {
        this.canBeCancelled = canBeCancelled;
    }
}
