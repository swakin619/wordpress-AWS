package org.ride.saferide;

import org.ride.saferide.model.*;
import org.sql2o.Sql2o;
import spark.ModelAndView;
import spark.Request;
import spark.Response;
import spark.Session;
import spark.template.thymeleaf.ThymeleafTemplateEngine;

import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

import static spark.Spark.*;
import static org.ride.saferide.util.Util.*;

/**
 * Author Swetha Gajam
 * Created on 4/12/2016.
 */
public class App {
    private static Model model;

    private static final String SESSION = "user";

    public static void main(String[] args) {
        // connect to database
        Sql2o sql2o = new Sql2o("jdbc:mysql://localhost:3306/saferide", "root", "");
        model = new SqlModel(sql2o);

        ThymeleafTemplateEngine thymeleafTemplateEngine = new ThymeleafTemplateEngine();

        staticFileLocation("/templates");

        // all filters here
        before("/students/*", App::authenticate);

        // home
        get("/", App::home, thymeleafTemplateEngine);

        // login and logout
        get("/login", App::home, thymeleafTemplateEngine);
        post("/login", App::login, thymeleafTemplateEngine);
        get("/logout", App::logout, thymeleafTemplateEngine);

        // students
        get("/students/home", App::studentsHome, thymeleafTemplateEngine);
        get("/students/", App::studentsHome, thymeleafTemplateEngine);
        get("/students/book", App::getScheduleForm, thymeleafTemplateEngine);
        post("/students/book", App::addSchedule, thymeleafTemplateEngine);
        get("/students/ride/:id", App::getRide, thymeleafTemplateEngine);
        get("/students/ride/cancel/:id", App::cancelRide, thymeleafTemplateEngine);
        get("/students/about", (req, res) -> new ModelAndView(new HashMap<>(), "/students/about"), thymeleafTemplateEngine);
        get("/students/contact", (req, res) -> new ModelAndView(new HashMap<>(), "/students/contact"), thymeleafTemplateEngine);
        get("/students/rides", App::getRides, thymeleafTemplateEngine);
        // get("/students/", App::getStudents, thymeleafTemplateEngine);

    }

    /**
     * Get all students
     * @param request Request
     * @param response Response
     * @return students
     */
    private static ModelAndView getStudents(Request request, Response response) {
        Map<String, Object> params = new HashMap<>();
        params.put("students", model.getStudents());
        return new ModelAndView(params, "students/students");
    }

    /**
     * Authenticate
     * @param request Request
     * @param response Response
     */
    private static void authenticate(Request request, Response response) {
        // check if there is a session object
        Student student = getStudentFromSession(request);
        if (student == null) {
            response.redirect("/login");
            halt();
        }
    }

    /**
     * Home page of the application
     * @param request Request
     * @param response Response
     * @return homeView
     */
    private static ModelAndView home(Request request, Response response) {
        // check if a session exists
        Student student = getStudentFromSession(request);
        if (student != null) {
            response.redirect("/students/home");
            halt();
        }
        return new ModelAndView(new HashMap<>(), "/home");
    }

    /**
     * Login
     * @param request Request
     * @param response Response
     * @return loginView
     */
    private static ModelAndView login(Request request, Response response) {
        String id = request.queryParams("id");
        String password = request.queryParams("password");
        Student student = model.getStudentById(id);
        if (student != null && student.getPassword().equals(password)) {
            // valid student
            request.session().attribute(SESSION, student);
            response.redirect("/students/home");
            halt();
        }

        Map<String, Object> params = new HashMap<>();
        params.put("message", new Message("Invalid User id or Password", "danger"));
        params.put("id", id);
        return new ModelAndView(params, "home");
    }

    /**
     * Student home page
     * @param request Request
     * @param response Response
     * @return homeView
     */
    private static ModelAndView studentsHome(Request request, Response response) {
        Map<String, Object> params = new HashMap<>();
        params.put("student", getStudentFromSession(request));
        return new ModelAndView(params, "students/home");
    }

    /**
     * Logout
     * @param request Request
     * @param response Response
     * @return loginView
     */
    private static ModelAndView logout(Request request, Response response) {
        request.session().invalidate();
        response.redirect("/");
        halt();
        return null;
    }

    /**
     * Get schedule form
     * @param request Request
     * @param response Response
     * @return scheduleFormView
     */
    private static ModelAndView getScheduleForm(Request request, Response response) {
        Student student = getStudentFromSession(request);

        Map<String, Object> params = new HashMap<>();
        fillParamsForSchedule(params, student);
        params.put("schedule", new Schedule());
        return new ModelAndView(params, "students/book");
    }

    /**
     * Submit the schedule form
     * @param request Request
     * @param response Response
     * @return scheduleView
     */
    private static ModelAndView addSchedule(Request request, Response response) {
        Student student = getStudentFromSession(request);
        Schedule schedule = getScheduleFromRequest(request);
        schedule.setStudentId(student.getId());
        Message message = new ScheduleValidator(model).validate(schedule);

        Map<String, Object> params = new HashMap<>();
        if (!message.getValues().isEmpty()) {
            // has errors
            // error message
            fillParamsForSchedule(params, student);
            params.put("message", message);
            params.put("schedule", schedule);
            return new ModelAndView(params, "students/book");
        }

        // validation successful
        // now add it to the database
        schedule.setStatus("new");
        long scheduleId = model.addSchedule(schedule);

        // return the new schedule details
        response.redirect("/students/ride/" + scheduleId + "?new=true");
        halt();

        return new ModelAndView(params, "students/success");
    }

    /**
     * Get all rides of a student
     * @return ridesView
     */
    private static ModelAndView getRides(Request request, Response response) {
        Student student = getStudentFromSession(request);
        List<Schedule> schedules = model.getSchedulesOfStudent(student.getId());
        schedules.forEach((schedule) -> {
            schedule.setStatusDesc("");
            if ("cancelled".equals(schedule.getStatus())) {
                schedule.setClassName("danger");
                schedule.setStatusDesc("Cancelled");
                return;
            }
            Date date = new Date();
            // if passed then passed status
            if (date.getTime() > schedule.getPickUpTime().getTime()) {
                if (date.getTime() < schedule.getDropTime().getTime()) {
                    // riding
                    schedule.setClassName("active");
                    schedule.setStatusDesc("Riding");
                } else {
                    // passed
                    schedule.setClassName("");
                    schedule.setStatusDesc("Passed");
                }
            } else {
                // still did not start
                schedule.setClassName("success");
                schedule.setStatusDesc("Get ready");
            }
        });
        Map<String, Object> params = new HashMap<>();
        params.put("schedules", schedules);
        return new ModelAndView(params, "students/rides");
    }

    /**
     * Get ride details
     * @param request Request
     * @param response Response
     * @return rideView
     */
    private static ModelAndView getRide(Request request, Response response) {
        int id = parseInt(request.params("id"));
        String newRide = request.queryParams("new");

        Map<String, Object> params = new HashMap<>();
        Schedule schedule = model.getSchedule(id);
        if (schedule == null) {
            params.put("message", new Message("This ride does not exist", "danger"));
            return new ModelAndView(params, "students/message");
        }
        Timestamp timestamp = schedule.getPickUpTime();
        Date date = new Date();

        if (timestamp.getTime() - date.getTime() >= 10 * 60 * 1000) {
            if (!"cancelled".equals(schedule.getStatus())) {
                params.put("cancel", true);
            }
        }

        if (newRide != null) {
            params.put("message", new Message("You have successfully booked a ride", "success"));
        }

        params.put("ride", schedule);
        return new ModelAndView(params, "students/ride");
    }

    private static ModelAndView cancelRide(Request request, Response response) {
        int id = parseInt(request.params("id"));
        Map<String, Object> params = new HashMap<>();
        Schedule schedule = model.getSchedule(id);

        if (schedule != null) {
            Timestamp timestamp = schedule.getPickUpTime();
            Date date = new Date();
            if (timestamp.getTime() - date.getTime() >= 10 * 60 * 1000
                && !"cancelled".equals(schedule.getStatus())) {
                // cancel the ride
                model.cancelSchedule(schedule);
                params.put("message", new Message("Ride has been cancelled", "success"));
            } else {
                params.put("message", new Message("Ride cannot be cancelled. " +
                        "You cannot cancel already cancelled ride or you should cancel the ride" +
                        " at least 10 minutes before departure", "danger"));
            }
        } else {
            params.put("message", new Message("Ride does not exist", "danger"));
        }

        return new ModelAndView(params, "students/message");
    }

    /**
     * Get passengers
     * @return passengers
     */
    private static List<Integer> getPassengers() {
        return Arrays.asList(1, 2, 3, 4, 5, 6);
    }

    /**
     * Get student from session
     * @param request Request
     * @return student
     */
    private static Student getStudentFromSession(Request request) {
        Session session = request.session();
        return null == session ? null : session.attribute(SESSION);
    }

    /**
     * Get schedule from query param
     * @param request Request
     * @return schedule
     */
    private static Schedule getScheduleFromRequest(Request request) {
        Schedule schedule = new Schedule();
        int sourceId = parseInt(request.queryParams("sourceId"));
        int destinationId = parseInt(request.queryParams("destinationId"));
        int driverId = parseInt(request.queryParams("driverId"));
        int passengers = parseInt(request.queryParams("passengers"));
        String type = request.queryParams("type");
        String pickUpTime = request.queryParams("pickUpTime");
        // convert pick up time to timestamp

        schedule.setSourceId(sourceId);
        schedule.setDestinationId(destinationId);
        schedule.setType(type);
        schedule.setPassengers(passengers);
        schedule.setDriverId(driverId);
        schedule.setPickUpTimeString(pickUpTime);
        return schedule;
    }

    /**
     * Get drivers based on gender
     * @param student student
     * @return drivers
     */
    private static List<Driver> getDriversFromStudentGender(Student student) {
        List<Driver> drivers = model.getDrivers();
        if ("female".equals(student.getGender())) {
            drivers = drivers .stream()
                    .filter(driver -> "female".equals(driver.getGender()))
                    .collect(Collectors.toList());
        }
        return drivers;
    }

    /**
     * Fill all required fields for schedule form
     * @param params Params for ModelAndView
     */
    private static void fillParamsForSchedule(Map<String, Object> params, Student student) {
        params.put("student", student);
        params.put("places", model.getPlaces());
        params.put("drivers", getDriversFromStudentGender(student));
        params.put("passengers", getPassengers());
    }
}

class ScheduleValidator {

    private Model model;

    ScheduleValidator(Model model) {
        this.model = model;
    }

    /**
     * Validate schedule
     * @param schedule Schedule
     * @return message if any validation errors or null
     */
    Message validate(Schedule schedule) {
        List<String> errors = new ArrayList<>();
        Message message = new Message(errors, "danger");

        if (schedule.getSourceId() == schedule.getDestinationId()) {
            errors.add("Source and Destination should not be same");
            // distance will be 0
        } else {
            // add the distance
            int distance = getDistance(schedule.getSourceId(), schedule.getDestinationId());
            schedule.setDistance(distance);
        }

        // get the source and destination
        try {
            Timestamp timestamp = Timestamp.valueOf(schedule.getPickUpTimeString());
            schedule.setPickUpTime(timestamp);
        } catch (Exception e) {
            errors.add("Pickup time is invalid");
            return message;
        }

        // check if the pick time is in future + 1 hour
        long currentTimestamp = (new java.util.Date()).getTime();
        // timestamp + hour
        long timestamp = schedule.getPickUpTime().getTime() + getFifteenMinutes();

        if (timestamp < currentTimestamp) {
            errors.add("You can only set the pick up time that " +
                    "is greater than 15 minutes of current time");
        }

        if (schedule.getDistance() > 5 && schedule.getDistance() < 10) {
            // book before 10 hours
            long longDistancePickUpTime = schedule.getPickUpTime().getTime() +
                    getTenHours();
            if (longDistancePickUpTime < currentTimestamp) {
                errors.add("You are trying to book a long distance ride. " +
                        "Booking should be done 10 hours before departure");
            }
        }

        // check if it is on sunday or saturday
        if (!isDateSelectedOnWeekend(schedule.getPickUpTime())) {
            errors.add("This service is only available on weekends");
            return message;
        }

        // check if the current timestamp is
        // greater than 10 pm and less than 4 am
        if (isTimeBetweenMentionedTimes(schedule.getPickUpTime())) {
            errors.add("Pick up time should be in between 10 pm and 4 am");
        }

        // check if
        if (schedule.getDriverId() == 0) {
            errors.add("Please select a driver");
        }

        // check if type of trip is selected
        if (isEmpty(schedule.getType())) {
            errors.add("Please select One way or round trip");
        }

        // check if the driver is available
        if (schedule.getDistance() != 0 && schedule.getDriverId() != 0) {
            // get all schedules of a driver
            // whose schedule conflict
            long endTime = schedule.getPickUpTime().getTime()
                    // 10 minutes for each mile
                    + schedule.getDistance() * 10 * 60 * 1000;
            // set the drop time
            schedule.setDropTime(new Timestamp(endTime));
            List<Schedule> schedules = model.getSchedulesOfDriverInTimes(
                    schedule.getDriverId(), schedule.getPickUpTime(), schedule.getDropTime()
            );
            if (schedules.size() > 0) {
                errors.add("The driver you have selected has schedule conflict." +
                        " Please select other driver");
            }
        }

        return message;
    }

    /**
     * Get current timestamp plus one hour
     * @return timestamp
     */
    private static long getFifteenMinutes() {
        return 15 * 60 * 1000;
    }

    private static long getTenHours() {
        return 10 * 60 * 60 * 1000;
    }

    /**
     * Check if time is between 10 pm and 4 am
     * @param timestamp Pick up timestamp
     * @return boolean
     */
    private static boolean isTimeBetweenMentionedTimes(Timestamp timestamp) {
        long pickupTimestamp = timestamp.getTime();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date(pickupTimestamp));
        calendar.set(Calendar.HOUR, 22);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        // 10 pm
        long time10pm = calendar.getTimeInMillis();

        calendar.add(Calendar.DAY_OF_YEAR, 1);
        calendar.set(Calendar.HOUR, 4);
        // 4 am
        long time4am = calendar.getTimeInMillis();

        return (pickupTimestamp >= time10pm && pickupTimestamp <= time4am);
    }

    /**
     * Return true if pickup time is on weekend
     * @param timestamp Timestamp
     * @return boolean
     */
    private static boolean isDateSelectedOnWeekend(Timestamp timestamp) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(timestamp.getTime());
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        return (dayOfWeek == 1 || dayOfWeek == 7);
    }

    /**
     * Get distance between source and destination
     * @param sourceId Source
     * @param destinationId Destination
     * @return distance
     */
    private static int getDistance(int sourceId, int destinationId) {
        return sourceId + destinationId;
    }
}
